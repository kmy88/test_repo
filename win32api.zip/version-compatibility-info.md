# Office Version Compatibility Guide

## 지원되는 Office 버전

이 MCP 도구는 다음 MS Office 버전들과 호환됩니다:

### Excel 지원 버전
- **Excel 2019/365** (Version 16.x) - ProgID: Excel.Application.16
- **Excel 2016** (Version 16.x) - ProgID: Excel.Application.16  
- **Excel 2013** (Version 15.x) - ProgID: Excel.Application.15
- **Excel 2010** (Version 14.x) - ProgID: Excel.Application.14
- **Excel 2007** (Version 12.x) - ProgID: Excel.Application.12
- **Excel 2003** (Version 11.x) - ProgID: Excel.Application.11
- **Excel XP** (Version 10.x) - ProgID: Excel.Application.10
- **Excel 2000** (Version 9.x) - ProgID: Excel.Application.9
- **Excel 97** (Version 8.x) - ProgID: Excel.Application.8
- **Excel 95** (Version 7.x) - ProgID: Excel.Application.7

### Word 지원 버전
- **Word 2019/365** (Version 16.x) - ProgID: Word.Application.16
- **Word 2016** (Version 16.x) - ProgID: Word.Application.16
- **Word 2013** (Version 15.x) - ProgID: Word.Application.15
- **Word 2010** (Version 14.x) - ProgID: Word.Application.14
- **Word 2007** (Version 12.x) - ProgID: Word.Application.12
- **Word 2003** (Version 11.x) - ProgID: Word.Application.11
- **Word XP** (Version 10.x) - ProgID: Word.Application.10
- **Word 2000** (Version 9.x) - ProgID: Word.Application.9
- **Word 97** (Version 8.x) - ProgID: Word.Application.8
- **Word 95** (Version 7.x) - ProgID: Word.Application.7

## 버전별 주요 기능 차이점

### Excel
- **2007 이후**: XLSX 형식 지원, 더 큰 워크시트 크기
- **2003 이전**: XLS 형식만 지원, 65,536행 제한
- **모든 버전**: 기본 셀 읽기, 워크시트 탐색 지원

### Word
- **2007 이후**: DOCX 형식 지원, Range.Text 사용으로 성능 향상
- **2003 이전**: DOC 형식만 지원, Content.Text 사용
- **모든 버전**: 텍스트 내용 추출, 기본 문서 정보 지원

## 버전 감지 방식

도구는 다음 순서로 Office 애플리케이션을 감지합니다:

1. 최신 버전부터 시작 (16, 15, 14, ...)
2. 각 ProgID를 순차적으로 시도
3. 첫 번째로 성공하는 연결을 사용
4. Generic ProgID를 마지막 fallback으로 사용

## 호환성 향상 기능

### 에러 처리
- 버전별 API 차이점 자동 처리
- 셀 값 읽기 실패 시 안전한 fallback
- 메모리 제한을 위한 데이터 크기 제한

### 데이터 정제
- JSON 호환성을 위한 특수 문자 처리
- 줄바꿈 문자 표준화
- 에러 값 (#ERROR#) 안전 처리

### 성능 최적화
- Excel: 1000행 x 50열 제한
- Word: 100KB 텍스트 제한
- 큰 문서의 경우 자동 잘림 처리

## 테스트 방법

```bash
# 버전 호환성 테스트 실행
node test-server.js
```

테스트는 다음을 확인합니다:
1. Office 버전 감지
2. 활성 문서 목록 조회
3. 문서 내용 읽기
4. 버전별 API 차이점 처리