import { spawn } from 'child_process';
import { promisify } from 'util';

export class OfficeDocumentReader {
  constructor() {
    this.activeXAvailable = this.checkActiveXAvailability();
  }

  checkActiveXAvailability() {
    try {
      return process.platform === 'win32';
    } catch (error) {
      console.error('ActiveX not available:', error.message);
      return false;
    }
  }

  async executeVBScript(script) {
    return new Promise((resolve, reject) => {
      const vbsProcess = spawn('cscript', ['//NoLogo', '//E:vbscript'], {
        stdio: ['pipe', 'pipe', 'pipe']
      });

      let output = '';
      let errorOutput = '';

      vbsProcess.stdout.on('data', (data) => {
        output += data.toString();
      });

      vbsProcess.stderr.on('data', (data) => {
        errorOutput += data.toString();
      });

      vbsProcess.on('close', (code) => {
        if (code === 0) {
          resolve(output.trim());
        } else {
          reject(new Error(`VBScript execution failed: ${errorOutput}`));
        }
      });

      vbsProcess.stdin.write(script);
      vbsProcess.stdin.end();
    });
  }

  async getActiveDocuments() {
    const script = `
    On Error Resume Next
    
    Dim result
    result = "{"
    
    ' Check Excel applications
    Set xlApp = GetObject(, "Excel.Application")
    If Not IsEmpty(xlApp) And Not xlApp Is Nothing Then
        result = result & """excel"":["
        For Each wb In xlApp.Workbooks
            result = result & """" & wb.Name & ""","
        Next
        If Right(result, 1) = "," Then
            result = Left(result, Len(result) - 1)
        End If
        result = result & "],"
    Else
        result = result & """excel"":[],"
    End If
    Set xlApp = Nothing
    
    ' Check Word applications
    Set wdApp = GetObject(, "Word.Application")
    If Not IsEmpty(wdApp) And Not wdApp Is Nothing Then
        result = result & """word"":["
        For Each doc In wdApp.Documents
            result = result & """" & doc.Name & ""","
        Next
        If Right(result, 1) = "," Then
            result = Left(result, Len(result) - 1)
        End If
        result = result & "]"
    Else
        result = result & """word"":[]"
    End If
    Set wdApp = Nothing
    
    result = result & "}"
    WScript.Echo result
    `;

    try {
      const output = await this.executeVBScript(script);
      return JSON.parse(output);
    } catch (error) {
      console.error('Error getting active documents:', error.message);
      return { excel: [], word: [] };
    }
  }

  async readExcelDocument(workbookName, sheetName = null) {
    const script = `
    On Error Resume Next
    
    Set xlApp = GetObject(, "Excel.Application")
    If IsEmpty(xlApp) Or xlApp Is Nothing Then
        WScript.Echo "Excel application not found"
        WScript.Quit 1
    End If
    
    Set wb = Nothing
    For Each workbook In xlApp.Workbooks
        If workbook.Name = "${workbookName}" Then
            Set wb = workbook
            Exit For
        End If
    Next
    
    If wb Is Nothing Then
        WScript.Echo "Workbook '${workbookName}' not found"
        WScript.Quit 1
    End If
    
    Set ws = Nothing
    If "${sheetName}" <> "null" And "${sheetName}" <> "" Then
        Set ws = wb.Worksheets("${sheetName}")
    Else
        Set ws = wb.ActiveSheet
    End If
    
    If ws Is Nothing Then
        WScript.Echo "Worksheet not found"
        WScript.Quit 1
    End If
    
    Dim result
    result = "{"
    result = result & """workbook"":""" & wb.Name & ""","
    result = result & """worksheet"":""" & ws.Name & ""","
    result = result & """data"":["
    
    Dim lastRow, lastCol
    lastRow = ws.UsedRange.Rows.Count
    lastCol = ws.UsedRange.Columns.Count
    
    For i = 1 To lastRow
        result = result & "["
        For j = 1 To lastCol
            Dim cellValue
            cellValue = ws.Cells(i, j).Value
            If IsEmpty(cellValue) Then
                cellValue = ""
            End If
            cellValue = Replace(cellValue, """", """""")
            result = result & """" & cellValue & ""","
        Next
        If Right(result, 1) = "," Then
            result = Left(result, Len(result) - 1)
        End If
        result = result & "],"
    Next
    
    If Right(result, 1) = "," Then
        result = Left(result, Len(result) - 1)
    End If
    result = result & "]}"
    
    WScript.Echo result
    `;

    try {
      const output = await this.executeVBScript(script);
      return JSON.parse(output);
    } catch (error) {
      throw new Error(`Failed to read Excel document: ${error.message}`);
    }
  }

  async readWordDocument(documentName) {
    const script = `
    On Error Resume Next
    
    Set wdApp = GetObject(, "Word.Application")
    If IsEmpty(wdApp) Or wdApp Is Nothing Then
        WScript.Echo "Word application not found"
        WScript.Quit 1
    End If
    
    Set doc = Nothing
    For Each document In wdApp.Documents
        If document.Name = "${documentName}" Then
            Set doc = document
            Exit For
        End If
    Next
    
    If doc Is Nothing Then
        WScript.Echo "Document '${documentName}' not found"
        WScript.Quit 1
    End If
    
    Dim content
    content = doc.Content.Text
    content = Replace(content, """", """""")
    content = Replace(content, vbCrLf, "\\n")
    content = Replace(content, vbCr, "\\n")
    content = Replace(content, vbLf, "\\n")
    
    WScript.Echo "{""document"":""" & doc.Name & """,""content"":""" & content & """}"
    `;

    try {
      const output = await this.executeVBScript(script);
      const result = JSON.parse(output);
      return result.content;
    } catch (error) {
      throw new Error(`Failed to read Word document: ${error.message}`);
    }
  }

  async summarizeDocument(documentName, documentType, summaryLength = 'medium') {
    let content;
    
    try {
      if (documentType === 'excel') {
        const excelData = await this.readExcelDocument(documentName);
        content = this.formatExcelDataForSummary(excelData);
      } else if (documentType === 'word') {
        content = await this.readWordDocument(documentName);
      } else {
        throw new Error('Unsupported document type');
      }

      return this.generateSummary(content, summaryLength, documentName, documentType);
    } catch (error) {
      throw new Error(`Failed to summarize document: ${error.message}`);
    }
  }

  formatExcelDataForSummary(excelData) {
    let formatted = `Excel Workbook: ${excelData.workbook}\\n`;
    formatted += `Active Sheet: ${excelData.worksheet}\\n`;
    formatted += `Data Summary:\\n`;
    
    if (excelData.data && excelData.data.length > 0) {
      formatted += `- Total rows: ${excelData.data.length}\\n`;
      formatted += `- Total columns: ${excelData.data[0] ? excelData.data[0].length : 0}\\n`;
      
      // Include first few rows as sample
      formatted += `- Sample data (first 5 rows):\\n`;
      for (let i = 0; i < Math.min(5, excelData.data.length); i++) {
        formatted += `  Row ${i + 1}: ${excelData.data[i].join(', ')}\\n`;
      }
    }
    
    return formatted;
  }

  generateSummary(content, summaryLength, documentName, documentType) {
    const wordCount = content.split(/\\s+/).length;
    const lineCount = content.split('\\n').length;
    
    let summary = `Document Summary\\n`;
    summary += `================\\n`;
    summary += `Document: ${documentName}\\n`;
    summary += `Type: ${documentType.toUpperCase()}\\n`;
    summary += `Word Count: ${wordCount}\\n`;
    summary += `Line Count: ${lineCount}\\n\\n`;
    
    if (summaryLength === 'short') {
      summary += `Brief Overview: This ${documentType} document contains ${wordCount} words across ${lineCount} lines.`;
    } else if (summaryLength === 'medium') {
      const preview = content.substring(0, 500);
      summary += `Content Preview:\\n${preview}${content.length > 500 ? '...' : ''}\\n\\n`;
      summary += `Analysis: This document appears to contain ${this.analyzeContentType(content, documentType)}.`;
    } else if (summaryLength === 'detailed') {
      const preview = content.substring(0, 1000);
      summary += `Full Content Preview:\\n${preview}${content.length > 1000 ? '...' : ''}\\n\\n`;
      summary += `Detailed Analysis:\\n`;
      summary += `- Content Type: ${this.analyzeContentType(content, documentType)}\\n`;
      summary += `- Key Topics: ${this.extractKeyTopics(content)}\\n`;
      summary += `- Structure: ${this.analyzeStructure(content, documentType)}`;
    }
    
    return summary;
  }

  analyzeContentType(content, documentType) {
    if (documentType === 'excel') {
      if (content.includes('Total') || content.includes('Sum') || content.includes('$')) {
        return 'financial or numerical data';
      } else if (content.includes('Date') || content.includes('Time')) {
        return 'time-based data or schedule';
      } else {
        return 'tabular data';
      }
    } else {
      if (content.includes('Dear') || content.includes('Sincerely')) {
        return 'correspondence or letter';
      } else if (content.includes('Introduction') || content.includes('Conclusion')) {
        return 'report or article';
      } else {
        return 'general text document';
      }
    }
  }

  extractKeyTopics(content) {
    const words = content.toLowerCase().split(/\\W+/);
    const wordCount = {};
    
    // Count significant words (longer than 4 characters)
    words.forEach(word => {
      if (word.length > 4) {
        wordCount[word] = (wordCount[word] || 0) + 1;
      }
    });
    
    // Get top 5 most frequent words
    const sortedWords = Object.entries(wordCount)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([word]) => word);
    
    return sortedWords.join(', ');
  }

  analyzeStructure(content, documentType) {
    if (documentType === 'excel') {
      return 'Spreadsheet with structured data in rows and columns';
    } else {
      const paragraphs = content.split('\\n\\n').length;
      return `Text document with approximately ${paragraphs} paragraphs`;
    }
  }
}