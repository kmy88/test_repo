import { spawn } from 'child_process';
import { promisify } from 'util';

export class OfficeDocumentReader {
  constructor() {
    this.activeXAvailable = this.checkActiveXAvailability();
    this.officeVersions = this.initOfficeVersions();
  }

  initOfficeVersions() {
    return {
      excel: {
        // Excel 버전별 ProgID (Office 95부터 최신까지)
        progIds: [
          'Excel.Application.16',  // Office 2016, 2019, 365
          'Excel.Application.15',  // Office 2013
          'Excel.Application.14',  // Office 2010
          'Excel.Application.12',  // Office 2007
          'Excel.Application.11',  // Office 2003
          'Excel.Application.10',  // Office XP
          'Excel.Application.9',   // Office 2000
          'Excel.Application.8',   // Office 97
          'Excel.Application.7',   // Office 95
          'Excel.Application'      // Generic fallback
        ]
      },
      word: {
        // Word 버전별 ProgID
        progIds: [
          'Word.Application.16',   // Office 2016, 2019, 365
          'Word.Application.15',   // Office 2013
          'Word.Application.14',   // Office 2010
          'Word.Application.12',   // Office 2007
          'Word.Application.11',   // Office 2003
          'Word.Application.10',   // Office XP
          'Word.Application.9',    // Office 2000
          'Word.Application.8',    // Office 97
          'Word.Application.7',    // Office 95
          'Word.Application'       // Generic fallback
        ]
      },
      powerpoint: {
        // PowerPoint 버전별 ProgID (향후 확장용)
        progIds: [
          'PowerPoint.Application.16',
          'PowerPoint.Application.15',
          'PowerPoint.Application.14',
          'PowerPoint.Application.12',
          'PowerPoint.Application.11',
          'PowerPoint.Application.10',
          'PowerPoint.Application.9',
          'PowerPoint.Application.8',
          'PowerPoint.Application'
        ]
      }
    };
  }

  checkActiveXAvailability() {
    try {
      return process.platform === 'win32';
    } catch (error) {
      console.error('ActiveX not available:', error.message);
      return false;
    }
  }

  async executeVBScript(script) {
    return new Promise((resolve, reject) => {
      const vbsProcess = spawn('cscript', ['//NoLogo', '//E:vbscript'], {
        stdio: ['pipe', 'pipe', 'pipe']
      });

      let output = '';
      let errorOutput = '';

      vbsProcess.stdout.on('data', (data) => {
        output += data.toString();
      });

      vbsProcess.stderr.on('data', (data) => {
        errorOutput += data.toString();
      });

      vbsProcess.on('close', (code) => {
        if (code === 0) {
          resolve(output.trim());
        } else {
          reject(new Error(`VBScript execution failed: ${errorOutput}`));
        }
      });

      vbsProcess.stdin.write(script);
      vbsProcess.stdin.end();
    });
  }

  async getActiveDocuments() {
    const script = `
    On Error Resume Next
    
    Dim result
    result = "{"
    
    ' Function to try multiple ProgIDs for Excel
    Function GetExcelApp()
        Dim progIds(9)
        progIds(0) = "Excel.Application.16"
        progIds(1) = "Excel.Application.15"
        progIds(2) = "Excel.Application.14"
        progIds(3) = "Excel.Application.12"
        progIds(4) = "Excel.Application.11"
        progIds(5) = "Excel.Application.10"
        progIds(6) = "Excel.Application.9"
        progIds(7) = "Excel.Application.8"
        progIds(8) = "Excel.Application.7"
        progIds(9) = "Excel.Application"
        
        For i = 0 To UBound(progIds)
            Set app = GetObject(, progIds(i))
            If Not IsEmpty(app) And Not app Is Nothing And Err.Number = 0 Then
                Set GetExcelApp = app
                Exit Function
            End If
            Err.Clear
        Next
        Set GetExcelApp = Nothing
    End Function
    
    ' Function to try multiple ProgIDs for Word
    Function GetWordApp()
        Dim progIds(9)
        progIds(0) = "Word.Application.16"
        progIds(1) = "Word.Application.15"
        progIds(2) = "Word.Application.14"
        progIds(3) = "Word.Application.12"
        progIds(4) = "Word.Application.11"
        progIds(5) = "Word.Application.10"
        progIds(6) = "Word.Application.9"
        progIds(7) = "Word.Application.8"
        progIds(8) = "Word.Application.7"
        progIds(9) = "Word.Application"
        
        For i = 0 To UBound(progIds)
            Set app = GetObject(, progIds(i))
            If Not IsEmpty(app) And Not app Is Nothing And Err.Number = 0 Then
                Set GetWordApp = app
                Exit Function
            End If
            Err.Clear
        Next
        Set GetWordApp = Nothing
    End Function
    
    ' Function to get version string safely
    Function GetVersionString(app)
        On Error Resume Next
        GetVersionString = app.Version
        If Err.Number <> 0 Then
            GetVersionString = "Unknown"
            Err.Clear
        End If
        On Error GoTo 0
    End Function
    
    ' Check Excel applications with version compatibility
    Set xlApp = GetExcelApp()
    If Not IsEmpty(xlApp) And Not xlApp Is Nothing Then
        Dim xlVersion
        xlVersion = GetVersionString(xlApp)
        result = result & """excel"":{""version"":""" & xlVersion & """,""documents"":["
        
        On Error Resume Next
        For Each wb In xlApp.Workbooks
            If Err.Number = 0 Then
                result = result & """" & wb.Name & ""","
            End If
        Next
        Err.Clear
        On Error GoTo 0
        
        If Right(result, 1) = "," Then
            result = Left(result, Len(result) - 1)
        End If
        result = result & "]},"
    Else
        result = result & """excel"":{""version"":"""",""documents"":[]},"
    End If
    Set xlApp = Nothing
    
    ' Check Word applications with version compatibility
    Set wdApp = GetWordApp()
    If Not IsEmpty(wdApp) And Not wdApp Is Nothing Then
        Dim wdVersion
        wdVersion = GetVersionString(wdApp)
        result = result & """word"":{""version"":""" & wdVersion & """,""documents"":["
        
        On Error Resume Next
        For Each doc In wdApp.Documents
            If Err.Number = 0 Then
                result = result & """" & doc.Name & ""","
            End If
        Next
        Err.Clear
        On Error GoTo 0
        
        If Right(result, 1) = "," Then
            result = Left(result, Len(result) - 1)
        End If
        result = result & "]}"
    Else
        result = result & """word"":{""version"":"""",""documents"":[]}"
    End If
    Set wdApp = Nothing
    
    result = result & "}"
    WScript.Echo result
    `;

    try {
      const output = await this.executeVBScript(script);
      const parsed = JSON.parse(output);
      // Transform to maintain backward compatibility while adding version info
      return {
        excel: parsed.excel ? parsed.excel.documents || [] : [],
        word: parsed.word ? parsed.word.documents || [] : [],
        versions: {
          excel: parsed.excel ? parsed.excel.version || 'Unknown' : 'Not Found',
          word: parsed.word ? parsed.word.version || 'Unknown' : 'Not Found'
        }
      };
    } catch (error) {
      console.error('Error getting active documents:', error.message);
      return { excel: [], word: [], versions: { excel: 'Error', word: 'Error' } };
    }
  }

  async readExcelDocument(workbookName, sheetName = null) {
    const script = `
    On Error Resume Next
    
    ' Function to try multiple ProgIDs for Excel
    Function GetExcelApp()
        Dim progIds(9)
        progIds(0) = "Excel.Application.16"
        progIds(1) = "Excel.Application.15"
        progIds(2) = "Excel.Application.14"
        progIds(3) = "Excel.Application.12"
        progIds(4) = "Excel.Application.11"
        progIds(5) = "Excel.Application.10"
        progIds(6) = "Excel.Application.9"
        progIds(7) = "Excel.Application.8"
        progIds(8) = "Excel.Application.7"
        progIds(9) = "Excel.Application"
        
        For i = 0 To UBound(progIds)
            Set app = GetObject(, progIds(i))
            If Not IsEmpty(app) And Not app Is Nothing And Err.Number = 0 Then
                Set GetExcelApp = app
                Exit Function
            End If
            Err.Clear
        Next
        Set GetExcelApp = Nothing
    End Function
    
    ' Function to safely get cell value (version compatible)
    Function GetCellValue(ws, row, col)
        On Error Resume Next
        Dim cellValue
        cellValue = ws.Cells(row, col).Value
        
        If Err.Number <> 0 Then
            GetCellValue = ""
            Err.Clear
            Exit Function
        End If
        
        If IsEmpty(cellValue) Then
            GetCellValue = ""
        ElseIf IsNull(cellValue) Then
            GetCellValue = ""
        ElseIf VarType(cellValue) = vbError Then
            GetCellValue = "#ERROR#"
        Else
            GetCellValue = CStr(cellValue)
        End If
        On Error GoTo 0
    End Function
    
    Set xlApp = GetExcelApp()
    If IsEmpty(xlApp) Or xlApp Is Nothing Then
        WScript.Echo "Excel application not found"
        WScript.Quit 1
    End If
    
    Set wb = Nothing
    For Each workbook In xlApp.Workbooks
        If workbook.Name = "${workbookName}" Then
            Set wb = workbook
            Exit For
        End If
    Next
    
    If wb Is Nothing Then
        WScript.Echo "Workbook '${workbookName}' not found"
        WScript.Quit 1
    End If
    
    Set ws = Nothing
    If "${sheetName}" <> "null" And "${sheetName}" <> "" Then
        On Error Resume Next
        Set ws = wb.Worksheets("${sheetName}")
        If Err.Number <> 0 Then
            Set ws = wb.Sheets("${sheetName}")
            Err.Clear
        End If
        On Error GoTo 0
    Else
        Set ws = wb.ActiveSheet
    End If
    
    If ws Is Nothing Then
        WScript.Echo "Worksheet not found"
        WScript.Quit 1
    End If
    
    Dim result
    result = "{"
    result = result & """workbook"":""" & wb.Name & ""","
    result = result & """worksheet"":""" & ws.Name & ""","
    
    ' Get Excel version for compatibility
    Dim xlVersion
    On Error Resume Next
    xlVersion = xlApp.Version
    If Err.Number <> 0 Then
        xlVersion = "Unknown"
        Err.Clear
    End If
    On Error GoTo 0
    result = result & """version"":""" & xlVersion & ""","
    
    result = result & """data"":["
    
    ' Version-compatible way to get used range
    Dim lastRow, lastCol, usedRange
    On Error Resume Next
    Set usedRange = ws.UsedRange
    If usedRange Is Nothing Or Err.Number <> 0 Then
        lastRow = 1
        lastCol = 1
        Err.Clear
    Else
        lastRow = usedRange.Rows.Count
        lastCol = usedRange.Columns.Count
        ' Handle potential errors in older Excel versions
        If lastRow <= 0 Then lastRow = 1
        If lastCol <= 0 Then lastCol = 1
    End If
    On Error GoTo 0
    
    ' Limit data size to prevent memory issues
    If lastRow > 1000 Then lastRow = 1000
    If lastCol > 50 Then lastCol = 50
    
    For i = 1 To lastRow
        result = result & "["
        For j = 1 To lastCol
            Dim cellValue
            cellValue = GetCellValue(ws, i, j)
            
            ' Clean up cell value for JSON
            cellValue = Replace(cellValue, """", """""")
            cellValue = Replace(cellValue, vbCrLf, " ")
            cellValue = Replace(cellValue, vbCr, " ")
            cellValue = Replace(cellValue, vbLf, " ")
            cellValue = Replace(cellValue, vbTab, " ")
            
            result = result & """" & cellValue & ""","
        Next
        If Right(result, 1) = "," Then
            result = Left(result, Len(result) - 1)
        End If
        result = result & "],"
    Next
    
    If Right(result, 1) = "," Then
        result = Left(result, Len(result) - 1)
    End If
    result = result & "]}"
    
    WScript.Echo result
    `;

    try {
      const output = await this.executeVBScript(script);
      return JSON.parse(output);
    } catch (error) {
      throw new Error(`Failed to read Excel document: ${error.message}`);
    }
  }

  async readWordDocument(documentName) {
    const script = `
    On Error Resume Next
    
    ' Function to try multiple ProgIDs for Word
    Function GetWordApp()
        Dim progIds(9)
        progIds(0) = "Word.Application.16"
        progIds(1) = "Word.Application.15"
        progIds(2) = "Word.Application.14"
        progIds(3) = "Word.Application.12"
        progIds(4) = "Word.Application.11"
        progIds(5) = "Word.Application.10"
        progIds(6) = "Word.Application.9"
        progIds(7) = "Word.Application.8"
        progIds(8) = "Word.Application.7"
        progIds(9) = "Word.Application"
        
        For i = 0 To UBound(progIds)
            Set app = GetObject(, progIds(i))
            If Not IsEmpty(app) And Not app Is Nothing And Err.Number = 0 Then
                Set GetWordApp = app
                Exit Function
            End If
            Err.Clear
        Next
        Set GetWordApp = Nothing
    End Function
    
    Set wdApp = GetWordApp()
    If IsEmpty(wdApp) Or wdApp Is Nothing Then
        WScript.Echo "Word application not found"
        WScript.Quit 1
    End If
    
    Set doc = Nothing
    For Each document In wdApp.Documents
        If document.Name = "${documentName}" Then
            Set doc = document
            Exit For
        End If
    Next
    
    If doc Is Nothing Then
        WScript.Echo "Document '${documentName}' not found"
        WScript.Quit 1
    End If
    
    ' Get Word version for compatibility
    Dim wdVersion
    On Error Resume Next
    wdVersion = wdApp.Version
    If Err.Number <> 0 Then
        wdVersion = "Unknown"
        Err.Clear
    End If
    On Error GoTo 0
    
    Dim content
    On Error Resume Next
    
    ' Version-compatible way to get document content
    If CDbl(wdVersion) >= 12.0 Then
        ' Office 2007 and later - use Range.Text for better performance
        content = doc.Range.Text
    Else
        ' Office 2003 and earlier - use Content.Text
        content = doc.Content.Text
    End If
    
    If Err.Number <> 0 Then
        ' Fallback method for very old versions or errors
        Err.Clear
        content = doc.Content.Text
        If Err.Number <> 0 Then
            content = "Unable to read document content"
            Err.Clear
        End If
    End If
    On Error GoTo 0
    
    If IsEmpty(content) Or IsNull(content) Then
        content = ""
    Else
        content = CStr(content)
    End If
    
    ' Clean up content for JSON
    content = Replace(content, """", """""")
    content = Replace(content, vbCrLf, "\\n")
    content = Replace(content, vbCr, "\\n")
    content = Replace(content, vbLf, "\\n")
    
    ' Limit content size to prevent memory issues (first 100KB)
    If Len(content) > 100000 Then
        content = Left(content, 100000) & "... [Content truncated]"
    End If
    
    WScript.Echo "{""document"":""" & doc.Name & """,""version"":""" & wdVersion & """,""content"":""" & content & """}"
    `;

    try {
      const output = await this.executeVBScript(script);
      const result = JSON.parse(output);
      return {
        content: result.content || '',
        version: result.version || 'Unknown',
        document: result.document || documentName
      };
    } catch (error) {
      throw new Error(`Failed to read Word document: ${error.message}`);
    }
  }

  async summarizeDocument(documentName, documentType, summaryLength = 'medium') {
    let content;
    let version = 'Unknown';
    
    try {
      if (documentType === 'excel') {
        const excelData = await this.readExcelDocument(documentName);
        content = this.formatExcelDataForSummary(excelData);
        version = excelData.version || 'Unknown';
      } else if (documentType === 'word') {
        const wordData = await this.readWordDocument(documentName);
        content = typeof wordData === 'string' ? wordData : wordData.content;
        version = wordData.version || 'Unknown';
      } else {
        throw new Error('Unsupported document type');
      }

      return this.generateSummary(content, summaryLength, documentName, documentType, version);
    } catch (error) {
      throw new Error(`Failed to summarize document: ${error.message}`);
    }
  }

  formatExcelDataForSummary(excelData) {
    let formatted = `Excel Workbook: ${excelData.workbook}\\n`;
    formatted += `Active Sheet: ${excelData.worksheet}\\n`;
    formatted += `Excel Version: ${excelData.version || 'Unknown'}\\n`;
    formatted += `Data Summary:\\n`;
    
    if (excelData.data && excelData.data.length > 0) {
      formatted += `- Total rows: ${excelData.data.length}\\n`;
      formatted += `- Total columns: ${excelData.data[0] ? excelData.data[0].length : 0}\\n`;
      
      // Include first few rows as sample
      formatted += `- Sample data (first 5 rows):\\n`;
      for (let i = 0; i < Math.min(5, excelData.data.length); i++) {
        formatted += `  Row ${i + 1}: ${excelData.data[i].join(', ')}\\n`;
      }
    }
    
    return formatted;
  }

  generateSummary(content, summaryLength, documentName, documentType, version = 'Unknown') {
    const wordCount = content.split(/\\s+/).length;
    const lineCount = content.split('\\n').length;
    
    let summary = `Document Summary\\n`;
    summary += `================\\n`;
    summary += `Document: ${documentName}\\n`;
    summary += `Type: ${documentType.toUpperCase()}\\n`;
    summary += `Office Version: ${version}\\n`;
    summary += `Word Count: ${wordCount}\\n`;
    summary += `Line Count: ${lineCount}\\n\\n`;
    
    if (summaryLength === 'short') {
      summary += `Brief Overview: This ${documentType} document (Office ${version}) contains ${wordCount} words across ${lineCount} lines.`;
    } else if (summaryLength === 'medium') {
      const preview = content.substring(0, 500);
      summary += `Content Preview:\\n${preview}${content.length > 500 ? '...' : ''}\\n\\n`;
      summary += `Analysis: This document appears to contain ${this.analyzeContentType(content, documentType)}.`;
    } else if (summaryLength === 'detailed') {
      const preview = content.substring(0, 1000);
      summary += `Full Content Preview:\\n${preview}${content.length > 1000 ? '...' : ''}\\n\\n`;
      summary += `Detailed Analysis:\\n`;
      summary += `- Content Type: ${this.analyzeContentType(content, documentType)}\\n`;
      summary += `- Key Topics: ${this.extractKeyTopics(content)}\\n`;
      summary += `- Structure: ${this.analyzeStructure(content, documentType)}`;
    }
    
    return summary;
  }

  analyzeContentType(content, documentType) {
    if (documentType === 'excel') {
      if (content.includes('Total') || content.includes('Sum') || content.includes('$')) {
        return 'financial or numerical data';
      } else if (content.includes('Date') || content.includes('Time')) {
        return 'time-based data or schedule';
      } else {
        return 'tabular data';
      }
    } else {
      if (content.includes('Dear') || content.includes('Sincerely')) {
        return 'correspondence or letter';
      } else if (content.includes('Introduction') || content.includes('Conclusion')) {
        return 'report or article';
      } else {
        return 'general text document';
      }
    }
  }

  extractKeyTopics(content) {
    const words = content.toLowerCase().split(/\\W+/);
    const wordCount = {};
    
    // Count significant words (longer than 4 characters)
    words.forEach(word => {
      if (word.length > 4) {
        wordCount[word] = (wordCount[word] || 0) + 1;
      }
    });
    
    // Get top 5 most frequent words
    const sortedWords = Object.entries(wordCount)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([word]) => word);
    
    return sortedWords.join(', ');
  }

  analyzeStructure(content, documentType) {
    if (documentType === 'excel') {
      return 'Spreadsheet with structured data in rows and columns';
    } else {
      const paragraphs = content.split('\\n\\n').length;
      return `Text document with approximately ${paragraphs} paragraphs`;
    }
  }

  // Version detection utility
  async getOfficeVersions() {
    try {
      const activeDocuments = await this.getActiveDocuments();
      return activeDocuments.versions || { excel: 'Not Found', word: 'Not Found' };
    } catch (error) {
      return { excel: 'Error', word: 'Error' };
    }
  }
}