# Universal Office Document Reader MCP Tool

MS Office 문서(Excel, Word)의 활성화된 문서 내용을 읽고 요약하는 범용 MCP(Model Context Protocol) 도구입니다.

## 주요 특징

- **범용 호환성**: Office 95부터 Office 365까지 모든 버전 지원
- **자동 버전 감지**: 설치된 Office 버전을 자동으로 감지하고 최적화
- **강력한 에러 처리**: 버전별 API 차이점 자동 처리
- **성능 최적화**: 메모리 효율적인 대용량 문서 처리

## 기능

- 현재 열려있는 MS Office 문서 목록 조회 (버전 정보 포함)
- Excel 워크북 데이터 읽기 (모든 Excel 버전 지원)
- Word 문서 텍스트 읽기 (모든 Word 버전 지원)
- Office 버전 정보 조회
- 문서 내용 자동 요약 (짧게/보통/상세)

## 지원되는 Office 버전

### Excel
- Excel 95 ~ Excel 365 (모든 버전)
- XLS, XLSX 형식 모두 지원

### Word  
- Word 95 ~ Word 365 (모든 버전)
- DOC, DOCX 형식 모두 지원

## 시스템 요구사항

- Windows 10/11
- MS Office (Excel, Word) 설치 (어떤 버전이든 가능)
- Node.js 18 이상

## 설치 및 실행

```bash
# 의존성 설치
npm install

# MCP 서버 실행
npm start
```

## 사용 방법

### Claude Desktop에서 사용

Claude Desktop의 설정 파일에 다음을 추가:

```json
{
  "mcpServers": {
    "office-reader": {
      "command": "node",
      "args": ["F:\\work_diir\\win32api\\index.js"],
      "cwd": "F:\\work_diir\\win32api"
    }
  }
}
```

### 사용 가능한 도구

1. **get_active_office_documents**: 현재 활성화된 Office 문서 목록 조회 (버전 정보 포함)
2. **get_office_versions**: 설치된 Office 애플리케이션 버전 정보 조회
3. **read_excel_document**: Excel 워크북 데이터 읽기 (모든 버전 호환)
4. **read_word_document**: Word 문서 텍스트 읽기 (모든 버전 호환)
5. **summarize_office_document**: 문서 내용 요약 (버전 정보 포함)

## 사용 예시

```javascript
// Office 버전 정보 조회
await getOfficeVersions();

// 활성화된 문서 목록 조회 (버전 정보 포함)
await getActiveOfficeDocuments();

// Excel 워크북 읽기 (모든 버전 호환)
await readExcelDocument("MyWorkbook.xlsx", "Sheet1");

// Word 문서 읽기 (모든 버전 호환)
await readWordDocument("MyDocument.docx");

// 문서 요약 생성 (버전별 최적화)
await summarizeOfficeDocument("MyWorkbook.xlsx", "excel", "medium");
```

## 버전 호환성

이 도구는 **Office 95부터 Office 365까지** 모든 버전을 지원합니다:

- 자동으로 설치된 Office 버전을 감지
- 버전별 ProgID를 순차적으로 시도
- API 차이점을 자동으로 처리
- 레거시 버전의 제한사항 자동 우회

상세한 호환성 정보는 `version-compatibility-info.md`를 참조하세요.

## 보안 참고사항

이 도구는 Windows의 COM(Component Object Model)을 통해 Office 애플리케이션에 접근합니다. 
실행 중인 Office 문서의 내용을 읽을 수 있으므로, 신뢰할 수 있는 환경에서만 사용하세요.

## 라이선스

MIT License