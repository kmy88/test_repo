import { OfficeDocumentReader } from './src/office-reader-universal.js';

async function testOfficeReader() {
  console.log('Testing Office Document Reader...\n');
  
  const reader = new OfficeDocumentReader();
  
  try {
    console.log('1. Testing Office version detection...');
    const versions = await reader.getOfficeVersions();
    console.log('Office versions:', JSON.stringify(versions, null, 2));
    
    console.log('\n2. Getting active documents...');
    const activeDocuments = await reader.getActiveDocuments();
    console.log('Active documents:', JSON.stringify(activeDocuments, null, 2));
    
    // Test Excel reading if Excel documents are found
    if (activeDocuments.excel && activeDocuments.excel.length > 0) {
      console.log('\n3. Testing Excel document reading...');
      try {
        const excelData = await reader.readExcelDocument(activeDocuments.excel[0]);
        console.log('Excel data sample:', JSON.stringify(excelData, null, 2));
        
        console.log('\n4. Testing Excel summary...');
        const excelSummary = await reader.summarizeDocument(
          activeDocuments.excel[0], 
          'excel', 
          'medium'
        );
        console.log('Excel summary:', excelSummary);
      } catch (error) {
        console.log('Excel test failed:', error.message);
      }
    } else {
      console.log('\n3. No Excel documents found for testing');
    }
    
    // Test Word reading if Word documents are found
    if (activeDocuments.word && activeDocuments.word.length > 0) {
      console.log('\n5. Testing Word document reading...');
      try {
        const wordData = await reader.readWordDocument(activeDocuments.word[0]);
        const wordContent = typeof wordData === 'string' ? wordData : wordData.content;
        const wordVersion = wordData.version || 'Unknown';
        console.log(`Word version: ${wordVersion}`);
        console.log('Word content preview:', wordContent.substring(0, 200) + '...');
        
        console.log('\n6. Testing Word summary...');
        const wordSummary = await reader.summarizeDocument(
          activeDocuments.word[0], 
          'word', 
          'short'
        );
        console.log('Word summary:', wordSummary);
      } catch (error) {
        console.log('Word test failed:', error.message);
      }
    } else {
      console.log('\n5. No Word documents found for testing');
    }
    
  } catch (error) {
    console.error('Test failed:', error.message);
  }
}

testOfficeReader();