#!/usr/bin/env node

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ErrorCode,
  ListToolsRequestSchema,
  McpError,
} from "@modelcontextprotocol/sdk/types.js";
import { OfficeDocumentReader } from "./src/office-reader-universal.js";

const server = new Server(
  {
    name: "office-document-reader",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

const officeReader = new OfficeDocumentReader();

server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "get_active_office_documents",
        description: "Get list of currently active MS Office documents with version information (Excel, Word)",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
      {
        name: "get_office_versions",
        description: "Get installed Office application versions",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
      {
        name: "read_excel_document",
        description: "Read content from an active Excel workbook",
        inputSchema: {
          type: "object",
          properties: {
            workbook_name: {
              type: "string",
              description: "Name of the Excel workbook to read",
            },
            sheet_name: {
              type: "string",
              description: "Name of the worksheet to read (optional, defaults to active sheet)",
            },
          },
          required: ["workbook_name"],
        },
      },
      {
        name: "read_word_document",
        description: "Read content from an active Word document",
        inputSchema: {
          type: "object",
          properties: {
            document_name: {
              type: "string",
              description: "Name of the Word document to read",
            },
          },
          required: ["document_name"],
        },
      },
      {
        name: "summarize_office_document",
        description: "Summarize content from an active Office document",
        inputSchema: {
          type: "object",
          properties: {
            document_name: {
              type: "string",
              description: "Name of the document to summarize",
            },
            document_type: {
              type: "string",
              enum: ["excel", "word"],
              description: "Type of document (excel or word)",
            },
            summary_length: {
              type: "string",
              enum: ["short", "medium", "detailed"],
              description: "Length of summary (default: medium)",
            },
          },
          required: ["document_name", "document_type"],
        },
      },
    ],
  };
});

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    switch (name) {
      case "get_active_office_documents":
        const documents = await officeReader.getActiveDocuments();
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify(documents, null, 2),
            },
          ],
        };

      case "get_office_versions":
        const versions = await officeReader.getOfficeVersions();
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify(versions, null, 2),
            },
          ],
        };

      case "read_excel_document":
        const excelContent = await officeReader.readExcelDocument(
          args.workbook_name,
          args.sheet_name
        );
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify(excelContent, null, 2),
            },
          ],
        };

      case "read_word_document":
        const wordContent = await officeReader.readWordDocument(args.document_name);
        return {
          content: [
            {
              type: "text",
              text: wordContent,
            },
          ],
        };

      case "summarize_office_document":
        const summary = await officeReader.summarizeDocument(
          args.document_name,
          args.document_type,
          args.summary_length || "medium"
        );
        return {
          content: [
            {
              type: "text",
              text: summary,
            },
          ],
        };

      default:
        throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${name}`);
    }
  } catch (error) {
    throw new McpError(ErrorCode.InternalError, error.message);
  }
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("Office Document Reader MCP server running on stdio");
}

main().catch((error) => {
  console.error("Server failed to start:", error);
  process.exit(1);
});