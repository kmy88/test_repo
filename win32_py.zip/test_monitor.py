from office_monitor import OfficeMonitor
import logging
import time

# 디버그 레벨로 로깅 설정
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('debug_monitor.log'),
        logging.StreamHandler()
    ]
)

def test_file_detection():
    """파일 감지 기능 테스트"""
    monitor = OfficeMonitor()
    
    print("=== Office 파일 감지 테스트 ===")
    print("Office 애플리케이션을 열고 파일을 여세요.")
    print("Ctrl+C를 눌러 종료하세요.\n")
    
    try:
        for i in range(60):  # 60초 동안 테스트
            print(f"\n--- 스캔 #{i+1} ---")
            
            # COM을 통한 파일 감지 테스트
            com_files = monitor.get_files_via_com()
            print("COM으로 감지된 파일들:")
            for app, files in com_files.items():
                if files:
                    print(f"  {app}: {files}")
                else:
                    print(f"  {app}: 없음")
            
            # 윈도우 제목을 통한 파일 감지 테스트
            all_files = monitor.get_open_office_files()
            print("\n전체 감지된 파일들:")
            for app, files in all_files.items():
                if files:
                    print(f"  {app}: {files}")
                else:
                    print(f"  {app}: 없음")
            
            time.sleep(3)
            
    except KeyboardInterrupt:
        print("\n테스트를 종료합니다.")

if __name__ == "__main__":
    test_file_detection()