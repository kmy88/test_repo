import psutil
import time
import win32gui
import win32process
import win32api
import win32con
from pathlib import Path
import pandas as pd
from docx import Document
from pptx import Presentation
import logging
from datetime import datetime
from typing import Dict, List, Optional, Set
import win32com.client as win32
import pythoncom

class OfficeMonitor:
    def __init__(self, output_format='markdown'):
        self.monitored_processes = {
            'EXCEL.EXE': 'Excel',
            'WINWORD.EXE': 'Word', 
            'POWERPNT.EXE': 'PowerPoint'
        }
        self.running_apps = {}
        self.previous_files = set()
        self.output_format = output_format.lower()
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('office_monitor.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def is_process_running(self, process_name: str) -> List[psutil.Process]:
        """특정 프로세스가 실행 중인지 확인"""
        running_processes = []
        for proc in psutil.process_iter(['pid', 'name', 'create_time']):
            try:
                if proc.info['name'].upper() == process_name.upper():
                    running_processes.append(proc)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return running_processes

    def get_window_file_path(self, hwnd) -> Optional[str]:
        """윈도우 핸들로부터 파일 경로 추출"""
        try:
            window_text = win32gui.GetWindowText(hwnd)
            if window_text and any(ext in window_text for ext in ['.xlsx', '.docx', '.pptx', '.xls', '.doc', '.ppt']):
                return window_text
        except:
            pass
        return None

    def get_open_office_files(self) -> Dict[str, List[str]]:
        """현재 열린 Office 파일들 감지 (COM + 윈도우 감지 결합)"""
        open_files = {app: [] for app in self.monitored_processes.values()}
        
        # COM을 통한 파일 감지 시도
        com_files = self.get_files_via_com()
        for app_name, files in com_files.items():
            open_files[app_name].extend(files)
        
        # 윈도우 열거를 통한 파일 감지
        def enum_windows_proc(hwnd, param):
            if win32gui.IsWindowVisible(hwnd):
                try:
                    _, pid = win32process.GetWindowThreadProcessId(hwnd)
                    process = psutil.Process(pid)
                    process_name = process.name().upper()
                    
                    if process_name in self.monitored_processes:
                        app_name = self.monitored_processes[process_name]
                        window_title = win32gui.GetWindowText(hwnd)
                        
                        if window_title and not any(x in window_title.lower() for x in ['시작', 'start', 'splash']):
                            file_path = self.extract_file_path_from_title(window_title, app_name)
                            if file_path and file_path not in open_files[app_name]:
                                open_files[app_name].append(file_path)
                except:
                    pass
            return True

        win32gui.EnumWindows(enum_windows_proc, None)
        
        # 중복 제거
        for app_name in open_files:
            open_files[app_name] = list(set(open_files[app_name]))
        
        return open_files

    def get_files_via_com(self) -> Dict[str, List[str]]:
        """COM 인터페이스를 통해 열린 파일들 가져오기"""
        com_files = {app: [] for app in self.monitored_processes.values()}
        
        try:
            # Excel 파일들
            try:
                xl = win32.GetActiveObject("Excel.Application")
                for wb in xl.Workbooks:
                    if wb.FullName and wb.FullName != wb.Name:  # 저장된 파일만
                        com_files['Excel'].append(wb.FullName)
            except:
                pass
            
            # Word 파일들
            try:
                word = win32.GetActiveObject("Word.Application")
                for doc in word.Documents:
                    if doc.FullName and doc.FullName != doc.Name:  # 저장된 파일만
                        com_files['Word'].append(doc.FullName)
            except:
                pass
            
            # PowerPoint 파일들
            try:
                ppt = win32.GetActiveObject("PowerPoint.Application")
                for presentation in ppt.Presentations:
                    if presentation.FullName and presentation.FullName != presentation.Name:  # 저장된 파일만
                        com_files['PowerPoint'].append(presentation.FullName)
            except:
                pass
                
        except Exception as e:
            self.logger.debug(f"COM을 통한 파일 감지 실패: {str(e)}")
        
        return com_files

    def extract_file_path_from_title(self, title: str, app_name: str) -> Optional[str]:
        """윈도우 제목에서 파일 경로 추출 (개선된 버전)"""
        if not title or title.strip() == "":
            return None
            
        self.logger.debug(f"윈도우 제목 분석 중: {title}")
        
        # 일반적인 패턴들을 제거
        title = title.replace(" [호환 모드]", "").replace(" [Compatibility Mode]", "")
        title = title.replace(" [읽기 전용]", "").replace(" [Read-Only]", "")
        
        file_extensions = {
            'Excel': ['.xlsx', '.xls', '.xlsm', '.xlsb'],
            'Word': ['.docx', '.doc', '.docm'],
            'PowerPoint': ['.pptx', '.ppt', '.pptm']
        }
        
        # 해당 앱의 확장자가 제목에 있는지 확인
        if app_name in file_extensions:
            has_extension = any(ext in title.lower() for ext in file_extensions[app_name])
            if not has_extension:
                return None
        
        # 앱 이름으로 제목 분리
        separators = {
            'Excel': [' - Microsoft Excel', ' - Excel'],
            'Word': [' - Microsoft Word', ' - Word'],
            'PowerPoint': [' - Microsoft PowerPoint', ' - PowerPoint']
        }
        
        file_name = title
        if app_name in separators:
            for sep in separators[app_name]:
                if sep in title:
                    file_name = title.split(sep)[0]
                    break
        
        # 파일명만 있는 경우 (전체 경로가 아닌 경우)
        if '\\' not in file_name and '/' not in file_name:
            # 최근 문서 폴더들에서 검색
            search_paths = [
                Path.home() / "Documents",
                Path.home() / "Desktop", 
                Path("C:/Users") / Path.home().name / "Documents",
                Path(".")  # 현재 디렉토리
            ]
            
            for search_path in search_paths:
                if search_path.exists():
                    for file_path in search_path.rglob(file_name):
                        if file_path.is_file():
                            self.logger.info(f"파일 경로 찾음: {file_path}")
                            return str(file_path)
            
            # 파일을 찾지 못한 경우 로그 출력
            self.logger.warning(f"파일을 찾을 수 없음: {file_name}")
            return None
        
        # 전체 경로인 경우
        if Path(file_name).exists():
            return file_name
        else:
            self.logger.warning(f"파일 경로가 존재하지 않음: {file_name}")
            return None

    def extract_excel_content(self, file_path: str) -> Dict:
        """Excel 파일 내용 추출"""
        try:
            if not Path(file_path).exists():
                return {"error": f"File not found: {file_path}"}
            
            df = pd.read_excel(file_path, sheet_name=None)
            content = {}
            
            for sheet_name, sheet_data in df.items():
                content[sheet_name] = {
                    "rows": len(sheet_data),
                    "columns": len(sheet_data.columns),
                    "data": sheet_data.head(10).to_dict('records'),
                    "column_names": list(sheet_data.columns)
                }
            
            return {
                "file_path": file_path,
                "sheets": content,
                "extracted_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {"error": str(e)}

    def extract_word_content(self, file_path: str) -> Dict:
        """Word 문서 내용 추출"""
        try:
            if not Path(file_path).exists():
                return {"error": f"File not found: {file_path}"}
            
            doc = Document(file_path)
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            
            tables = []
            for table in doc.tables:
                table_data = []
                for row in table.rows:
                    row_data = [cell.text for cell in row.cells]
                    table_data.append(row_data)
                tables.append(table_data)
            
            return {
                "file_path": file_path,
                "paragraph_count": len(paragraphs),
                "paragraphs": paragraphs[:10],  # 처음 10개 문단만
                "tables": tables,
                "extracted_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {"error": str(e)}

    def extract_powerpoint_content(self, file_path: str) -> Dict:
        """PowerPoint 프레젠테이션 내용 추출"""
        try:
            if not Path(file_path).exists():
                return {"error": f"File not found: {file_path}"}
            
            prs = Presentation(file_path)
            slides_content = []
            
            for i, slide in enumerate(prs.slides):
                slide_text = []
                for shape in slide.shapes:
                    if hasattr(shape, "text"):
                        slide_text.append(shape.text)
                
                slides_content.append({
                    "slide_number": i + 1,
                    "text_content": slide_text
                })
            
            return {
                "file_path": file_path,
                "slide_count": len(prs.slides),
                "slides": slides_content,
                "extracted_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {"error": str(e)}

    def extract_content_by_type(self, file_path: str, app_name: str) -> Dict:
        """파일 타입에 따른 내용 추출"""
        if app_name == 'Excel':
            return self.extract_excel_content(file_path)
        elif app_name == 'Word':
            return self.extract_word_content(file_path)
        elif app_name == 'PowerPoint':
            return self.extract_powerpoint_content(file_path)
        else:
            return {"error": "Unsupported application type"}

    def monitor_applications(self, check_interval: int = 5):
        """Office 애플리케이션 모니터링 시작"""
        self.logger.info("Office 애플리케이션 모니터링을 시작합니다...")
        
        while True:
            try:
                current_files = set()
                
                for process_name, app_name in self.monitored_processes.items():
                    processes = self.is_process_running(process_name)
                    
                    if processes:
                        if app_name not in self.running_apps:
                            self.logger.info(f"{app_name} 실행 감지됨")
                            self.running_apps[app_name] = {
                                'start_time': datetime.now(),
                                'processes': processes
                            }
                    else:
                        if app_name in self.running_apps:
                            self.logger.info(f"{app_name} 종료 감지됨")
                            del self.running_apps[app_name]
                
                # 열린 파일들 확인
                open_files = self.get_open_office_files()
                
                for app_name, files in open_files.items():
                    if files:  # 파일이 감지된 경우에만 로그 출력
                        self.logger.debug(f"{app_name}에서 감지된 파일들: {files}")
                    
                    for file_path in files:
                        current_files.add((app_name, file_path))
                        
                        if (app_name, file_path) not in self.previous_files:
                            self.logger.info(f"새 파일 열림 감지: {app_name} - {file_path}")
                            
                            # 파일 존재 여부 확인
                            if not Path(file_path).exists():
                                self.logger.error(f"파일이 존재하지 않음: {file_path}")
                                continue
                            
                            # 파일 내용 추출
                            content = self.extract_content_by_type(file_path, app_name)
                            if "error" not in content:
                                self.logger.info(f"파일 내용 추출 완료: {file_path}")
                                self.save_extracted_content(content, app_name, self.output_format)
                            else:
                                self.logger.error(f"내용 추출 실패: {content['error']}")
                
                self.previous_files = current_files
                time.sleep(check_interval)
                
            except KeyboardInterrupt:
                self.logger.info("모니터링을 중단합니다...")
                break
            except Exception as e:
                self.logger.error(f"모니터링 중 오류 발생: {str(e)}")
                time.sleep(check_interval)

    def save_extracted_content(self, content: Dict, app_name: str, format_type: str = 'markdown'):
        """추출된 내용을 파일로 저장 (Markdown 또는 Text 형식)"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if format_type.lower() == 'markdown':
            filename = f"extracted_{app_name.lower()}_{timestamp}.md"
            self.save_as_markdown(content, app_name, filename)
        else:
            filename = f"extracted_{app_name.lower()}_{timestamp}.txt"
            self.save_as_text(content, app_name, filename)
    
    def save_as_markdown(self, content: Dict, app_name: str, filename: str):
        """Markdown 형식으로 저장"""
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                # 헤더
                f.write(f"# {app_name} 파일 내용 추출\n\n")
                f.write(f"**추출 시간:** {content.get('extracted_at', 'Unknown')}  \n")
                f.write(f"**파일 경로:** `{content.get('file_path', 'Unknown')}`\n\n")
                f.write("---\n\n")
                
                if app_name == 'Excel':
                    self.write_excel_markdown(f, content)
                elif app_name == 'Word':
                    self.write_word_markdown(f, content)
                elif app_name == 'PowerPoint':
                    self.write_powerpoint_markdown(f, content)
            
            self.logger.info(f"추출된 내용이 {filename}에 Markdown 형식으로 저장되었습니다")
        
        except Exception as e:
            self.logger.error(f"Markdown 파일 저장 중 오류: {str(e)}")
    
    def write_excel_markdown(self, f, content: Dict):
        """Excel 내용을 Markdown으로 작성"""
        sheets = content.get('sheets', {})
        f.write(f"## 📊 Excel 파일 정보\n\n")
        f.write(f"**시트 개수:** {len(sheets)}\n\n")
        
        for sheet_name, sheet_info in sheets.items():
            f.write(f"### 📋 시트: {sheet_name}\n\n")
            f.write(f"- **행 수:** {sheet_info['rows']}\n")
            f.write(f"- **열 수:** {sheet_info['columns']}\n")
            f.write(f"- **컬럼명:** `{', '.join(sheet_info['column_names'])}`\n\n")
            
            # 데이터 테이블 (상위 5개 행)
            if sheet_info.get('data'):
                f.write("#### 📋 데이터 미리보기 (상위 5개 행)\n\n")
                
                # 테이블 헤더
                columns = sheet_info['column_names'][:10]  # 최대 10개 컬럼만 표시
                f.write("| " + " | ".join(columns) + " |\n")
                f.write("| " + " | ".join(["---"] * len(columns)) + " |\n")
                
                # 테이블 데이터
                for row in sheet_info['data'][:5]:
                    row_data = []
                    for col in columns:
                        value = str(row.get(col, ''))
                        # Markdown 특수문자 이스케이프
                        value = value.replace('|', '\\|').replace('\n', ' ')
                        if len(value) > 50:
                            value = value[:47] + "..."
                        row_data.append(value)
                    f.write("| " + " | ".join(row_data) + " |\n")
                f.write("\n")
    
    def write_word_markdown(self, f, content: Dict):
        """Word 내용을 Markdown으로 작성"""
        f.write(f"## 📄 Word 문서 정보\n\n")
        f.write(f"**문단 수:** {content.get('paragraph_count', 0)}  \n")
        f.write(f"**테이블 수:** {len(content.get('tables', []))}\n\n")
        
        # 문단 내용
        paragraphs = content.get('paragraphs', [])
        if paragraphs:
            f.write("### 📝 문단 내용 (상위 10개)\n\n")
            for i, paragraph in enumerate(paragraphs[:10]):
                if paragraph.strip():
                    # 긴 문단은 줄여서 표시
                    if len(paragraph) > 200:
                        paragraph = paragraph[:197] + "..."
                    f.write(f"**문단 {i+1}:**  \n{paragraph}\n\n")
        
        # 테이블 내용
        tables = content.get('tables', [])
        if tables:
            f.write("### 📊 테이블 내용\n\n")
            for table_idx, table_data in enumerate(tables[:3]):  # 최대 3개 테이블
                f.write(f"#### 테이블 {table_idx + 1}\n\n")
                if table_data and len(table_data) > 0:
                    # 테이블 헤더 (첫 번째 행을 헤더로 가정)
                    headers = table_data[0][:5]  # 최대 5개 컬럼
                    f.write("| " + " | ".join(headers) + " |\n")
                    f.write("| " + " | ".join(["---"] * len(headers)) + " |\n")
                    
                    # 테이블 데이터
                    for row in table_data[1:6]:  # 최대 5개 행
                        row_cells = row[:5]  # 최대 5개 컬럼
                        # 빈 셀 채우기
                        while len(row_cells) < len(headers):
                            row_cells.append("")
                        # 특수문자 이스케이프
                        escaped_cells = [cell.replace('|', '\\|').replace('\n', ' ') for cell in row_cells]
                        f.write("| " + " | ".join(escaped_cells) + " |\n")
                f.write("\n")
    
    def write_powerpoint_markdown(self, f, content: Dict):
        """PowerPoint 내용을 Markdown으로 작성"""
        f.write(f"## 🎯 PowerPoint 프레젠테이션 정보\n\n")
        f.write(f"**슬라이드 수:** {content.get('slide_count', 0)}\n\n")
        
        slides = content.get('slides', [])
        if slides:
            f.write("### 📑 슬라이드 내용\n\n")
            for slide in slides[:10]:  # 최대 10개 슬라이드
                f.write(f"#### 🔹 슬라이드 {slide['slide_number']}\n\n")
                
                text_content = slide.get('text_content', [])
                if text_content:
                    for text in text_content:
                        if text.strip():
                            # 텍스트가 긴 경우 줄여서 표시
                            if len(text) > 300:
                                text = text[:297] + "..."
                            f.write(f"- {text}\n")
                    f.write("\n")
                else:
                    f.write("*텍스트 내용 없음*\n\n")
    
    def save_as_text(self, content: Dict, app_name: str, filename: str):
        """기존 텍스트 형식으로 저장"""
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(f"=== {app_name} 파일 내용 추출 ===\n")
                f.write(f"추출 시간: {content.get('extracted_at', 'Unknown')}\n")
                f.write(f"파일 경로: {content.get('file_path', 'Unknown')}\n\n")
                
                if app_name == 'Excel':
                    f.write(f"시트 개수: {len(content.get('sheets', {}))}\n")
                    for sheet_name, sheet_info in content.get('sheets', {}).items():
                        f.write(f"\n[시트: {sheet_name}]\n")
                        f.write(f"행 수: {sheet_info['rows']}, 열 수: {sheet_info['columns']}\n")
                        f.write(f"컬럼명: {', '.join(sheet_info['column_names'])}\n")
                
                elif app_name == 'Word':
                    f.write(f"문단 수: {content.get('paragraph_count', 0)}\n")
                    f.write(f"테이블 수: {len(content.get('tables', []))}\n")
                    for i, paragraph in enumerate(content.get('paragraphs', [])[:5]):
                        f.write(f"문단 {i+1}: {paragraph}\n")
                
                elif app_name == 'PowerPoint':
                    f.write(f"슬라이드 수: {content.get('slide_count', 0)}\n")
                    for slide in content.get('slides', [])[:3]:  # 처음 3개 슬라이드만
                        f.write(f"\n슬라이드 {slide['slide_number']}:\n")
                        for text in slide['text_content']:
                            if text.strip():
                                f.write(f"  - {text}\n")
            
            self.logger.info(f"추출된 내용이 {filename}에 저장되었습니다")
        
        except Exception as e:
            self.logger.error(f"파일 저장 중 오류: {str(e)}")

def main():
    import sys
    
    # 명령줄 인수에서 출력 형식 설정
    output_format = 'markdown'  # 기본값
    if len(sys.argv) > 1:
        format_arg = sys.argv[1].lower()
        if format_arg in ['text', 'txt']:
            output_format = 'text'
        elif format_arg in ['markdown', 'md']:
            output_format = 'markdown'
    
    monitor = OfficeMonitor(output_format=output_format)
    
    print("=== Office 애플리케이션 모니터 ===")
    print("Excel, Word, PowerPoint 실행 및 파일 열기를 감지합니다.")
    print(f"출력 형식: {output_format.upper()}")
    print("사용법: python office_monitor.py [markdown|text]")
    print("Ctrl+C를 눌러 종료하세요.\n")
    
    try:
        monitor.monitor_applications()
    except KeyboardInterrupt:
        print("\n프로그램을 종료합니다.")

if __name__ == "__main__":
    main()